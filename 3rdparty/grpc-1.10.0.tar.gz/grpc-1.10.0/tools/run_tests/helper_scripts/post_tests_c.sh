#!/bin/bash
# Copyright 2015 gRPC authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

set -ex

if [ "$CONFIG" != "gcov" ] ; then exit ; fi

root=$(readlink -f "$(dirname "$0")/../../..")
out=$root/reports/c_cxx_coverage
tmp1=$(mktemp)
tmp2=$(mktemp)
cd "$root"
lcov --capture --directory . --output-file "$tmp1"
lcov --extract "$tmp1" "$root/src/*" "$root/include/*" --output-file "$tmp2"
genhtml "$tmp2" --output-directory "$out"
rm "$tmp2"
rm "$tmp1"

