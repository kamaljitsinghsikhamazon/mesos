HTTP/2 Interop Tests
====

This is a suite of tests that check a server to see if it plays nicely with other HTTP/2 clients.  To run, just type:

`go test -spec :1234`

Where ":1234" is the ip:port of a running server.
 
